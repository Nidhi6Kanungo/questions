import java.time.LocalDate;

public class WatchDetails {
	private String watchId;
	private String brandName;
	private String modelName;
	private LocalDate releaseDate;
	private double price;
	
	public WatchDetails(String watchId, String brandName, String modelName, LocalDate releaseDate, double price) {
		super();
		this.watchId = watchId;
		this.brandName = brandName;
		this.modelName = modelName;
		this.releaseDate = releaseDate;
		this.price = price;
	}
	public String getWatchId() {
		return watchId;
	}
	public void setWatchId(String watchId) {
		this.watchId = watchId;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public LocalDate getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Watch Brand: "+ brandName + ", Watch model: "+ modelName + ", Release Date: " + releaseDate + ", Price: " + price;
	}
	
	
}
