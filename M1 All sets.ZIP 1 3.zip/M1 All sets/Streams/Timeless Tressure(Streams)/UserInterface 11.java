import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class UserInterface {
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Enter the number of Watch Detail to be added:");
		int n = sc.nextInt();
		sc.nextLine();
		
		DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		System.out.println("Enter the Watch details:");  
		List<WatchDetails> list = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			String details= sc.nextLine();
			String[] arr = details.split(":");
			String dt = arr[3];
			//LocalDate date = ;
			double price = Double.parseDouble(arr[4]);
			
			WatchDetails watchDetails = new WatchDetails(arr[0], arr[1], arr[2], LocalDate.parse(dt, df), price);
			list.add(watchDetails);
		}
		
		WatchUtility watchUtility = new WatchUtility();
		System.out.println("Enter the brand name");
		String brandName = sc.nextLine();
		Stream<WatchDetails> detailsByBrandName = watchUtility.retrieveWatchDetailsByBrandName(list, brandName);
		List<WatchDetails> list2 = detailsByBrandName.toList();
		if(list2.isEmpty()) {
			System.out.println("No watch details found for the given brand "+ brandName);
		}
		else {
			System.out.println("Watch details for the given brand");
			for(WatchDetails watch: list2) {
				System.out.println(watch);
			}
		}
		
		System.out.println("Watch details in ascending order based on release date:");
		Stream<WatchDetails> retrieveWatchDetailsInAscendingOrderByReleaseDate = watchUtility.retrieveWatchDetailsInAscendingOrderByReleaseDate(list);
		retrieveWatchDetailsInAscendingOrderByReleaseDate.forEach(System.out::println);
		
		System.out.println("Enter the price to search");
		double watchPrice = sc.nextDouble();
		
		List<WatchDetails> retrieveWatchDetailsBelowTheSpecifiedPrice = watchUtility.retrieveWatchDetailsBelowTheSpecifiedPrice(detailsByBrandName, watchPrice);
		if(retrieveWatchDetailsBelowTheSpecifiedPrice.isEmpty()) {
			System.out.println("No watch found below the specified price");
		}
		else {
			for(WatchDetails w: retrieveWatchDetailsBelowTheSpecifiedPrice) {
				System.out.println(w);
			}
			
		}
	}
		
	
}
