import java.util.List;
import java.util.stream.Stream;

public class WatchUtility {

	 public Stream<WatchDetails> retrieveWatchDetailsByBrandName(List<WatchDetails> watchDetailsList, String brandName) {
		 return watchDetailsList.stream().filter(w -> w.getBrandName().equals(brandName));
 
	 }
	 
	 public List<WatchDetails> retrieveWatchDetailsBelowTheSpecifiedPrice(Stream<WatchDetails> watchDetailsStream, double price) {
		 return watchDetailsStream.filter(p-> p.getPrice() < price).toList();
		 
		
	 }
	 
	 public Stream<WatchDetails> retrieveWatchDetailsInAscendingOrderByReleaseDate(List<WatchDetails> watchDetailsList) {
		 return watchDetailsList.stream().sorted((d1, d2) -> d1.getReleaseDate().compareTo(d2.getReleaseDate()));

	 }

}
