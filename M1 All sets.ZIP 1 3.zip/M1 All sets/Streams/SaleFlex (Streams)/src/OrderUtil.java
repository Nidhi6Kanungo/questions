import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OrderUtil {

    public Stream<Order> getOrdersPlacedAfterGivenDate(Stream<Order> orderStream, LocalDate orderDate) {
    	List<Order> collect = orderStream.filter(p -> p.getOrderDate().isAfter(orderDate)).toList();
    	
    	return collect.stream();
    }

    public List<Order> getFirstNOrderDetails(Stream<Order> orderStream, int n) {
        List<Order> list = orderStream.limit(n).collect(Collectors.toList());
        return list;
    }

//    public Map<String, Order> findMinAndMaxOrderDetails(Stream<Order> orderStream) {
//        Optional<Order> minOrder = orderStream.min((o1, o2) -> Double.compare(o1.getOrderValue(), o2.getOrderValue()));
//        Optional<Order> maxOrder = orderStream.max((o1, o2) -> Double.compare(o1.getOrderValue(), o2.getOrderValue()));
//
//        return Map.of(
//            "min", minOrder.orElse(null),
//            "max", maxOrder.orElse(null)
//        );
//    }

    public List<Integer> findMinAndMaxOrderDetails(Stream<Integer> orderStream) {
        List<Integer> list = orderStream.sorted().toList();
        list.get(0);
        list.get(list.size()-1);
        return list;
    }
}
