import java.time.LocalDate;

public class Order {
	private String orderId;
	private String customerName;
	private String productName;
	private LocalDate orderDate;
	private double orderValue;

	public Order() {
		super();
	}

	public Order(String orderId, String customerName, String productName, LocalDate orderDate, double orderValue) {
		super();
		this.orderId = orderId;
		this.customerName = customerName;
		this.productName = productName;
		this.orderDate = orderDate;
		this.orderValue = orderValue;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public double getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(double orderValue) {
		this.orderValue = orderValue;
	}

	@Override
	public String toString() {
		return orderId + "|" + customerName + "|" + productName + "|" + orderDate + "|" + orderValue;
	}

}
