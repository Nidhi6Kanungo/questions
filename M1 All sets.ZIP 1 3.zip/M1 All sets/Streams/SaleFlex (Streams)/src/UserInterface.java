import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Stream;

public class UserInterface {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		OrderUtil utility = new OrderUtil();

		System.out.println("Enter the number of orders:");
		int totalOrders = sc.nextInt();
		sc.nextLine(); 

		List<Order> orders = new ArrayList<>();

		System.out.println("Enter the order details");
		for (int i = 0; i < totalOrders; i++) {
			String[] orderDetails = sc.nextLine().split(":");

			if (orderDetails.length == 5) {
				try {
					String orderId = orderDetails[0];
					String customerName = orderDetails[1];
					String productName = orderDetails[2];
					LocalDate orderDate = LocalDate.parse(orderDetails[3], DateTimeFormatter.ISO_LOCAL_DATE);
					double orderValue = Double.parseDouble(orderDetails[4]);

					orders.add(new Order(orderId, customerName, productName, orderDate, orderValue));
				} catch (Exception e) {
					System.out.println("Invalid order details. Please enter in the correct format.");
				}
			}
		}

		System.out.println("Enter the date to find orders after this date (format: YYYY-MM-DD):");
		LocalDate date = LocalDate.parse(sc.nextLine(), DateTimeFormatter.ISO_LOCAL_DATE);

		Stream<Order> orderStream = orders.stream();
		Stream<Order> filteredOrders = utility.getOrdersPlacedAfterGivenDate(orderStream, date);

		System.out.println("Orders placed after " + date + ":");
		filteredOrders.forEach(System.out::println);

		System.out.println("Enter the number of orders to retrieve:");
		int n = sc.nextInt();
		sc.nextLine(); 

		List<Order> firstNOrderDetails = utility.getFirstNOrderDetails(orders.stream(), n);

		System.out.println("First " + n + " orders are:");
		firstNOrderDetails.forEach(System.out::println);

		Map<String, Order> minAndMaxOrders = utility.findMinAndMaxOrderDetails(orders.stream());

		System.out.println("Order with minimum value:");
		System.out.println(minAndMaxOrders.get("min"));

		System.out.println("Order with maximum value:");
		System.out.println(minAndMaxOrders.get("max"));
	}
}
