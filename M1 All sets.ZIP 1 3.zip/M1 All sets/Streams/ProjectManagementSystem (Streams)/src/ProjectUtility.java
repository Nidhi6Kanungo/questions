import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ProjectUtility {

    public List<Project> retrieveProjectsByManager(Stream<Project> projectStream, String managerName) {
        //Fill the code here
    	List<Project> list = new ArrayList<Project>();
    	 list = projectStream.filter(e-> e.getManagerName().equalsIgnoreCase(managerName)).toList();
         
    	 if(list.isEmpty())
    		 return null;
    	 return list;
    }

    public List<Project> retrieveProjectsByStatus(Stream<Project> projectStream, String status) {
        List<Project> list = new ArrayList<Project>();
     	//if(status.equalsIgnoreCase("Completed")||status.equalsIgnoreCase("Pending")||status.equalsIgnoreCase("In progress")) {
        return projectStream.filter(e->e.getStatus().equalsIgnoreCase(status)).toList();
    	//}
    	//return list;
    }

    public List<Project> retrieveProjectsExceedingBudget(Stream<Project> projectStream, double budgetLimit) {
        // Fill the code here
        return projectStream.filter(e->e.getBudget()>budgetLimit).toList();
    }
}
