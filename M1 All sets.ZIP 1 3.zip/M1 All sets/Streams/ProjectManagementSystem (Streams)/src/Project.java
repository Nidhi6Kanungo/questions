public class Project {
    private String projectName;
    private String managerName;
    private double budget;
    private String status;

    public Project() {
        super();
    }

    public Project(String projectName, String managerName, double budget, String status) {
        super();
        this.projectName = projectName;
        this.managerName = managerName;
        this.budget = budget;
        this.status = status;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

    
}
