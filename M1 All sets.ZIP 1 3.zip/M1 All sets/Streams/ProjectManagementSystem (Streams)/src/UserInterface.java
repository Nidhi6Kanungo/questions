import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserInterface {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Project> projectList = new ArrayList<>();
        ProjectUtility pu = new ProjectUtility();
        System.out.println("Enter the total number of projects needed to add in the list");
        int totalProjects = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter the project details (projectName,managerName,budget,status)");
        for (int i = 0; i < totalProjects; i++) {
            String[] details = scanner.nextLine().split(",");
            String pName = details[0];
            String manName = details[1];
            double budget = Double.parseDouble(details[2]);
            String status = details[3];
            Project p = new Project(pName, manName, budget, status);
            projectList.add(p);
   
        }
        
        System.out.println("Enter the manager name");
        String manName = scanner.nextLine();
        
        List<Project> projectsByManager = pu.retrieveProjectsByManager(projectList.stream(), manName);
        
        if(projectsByManager==null) {
        	System.out.println("No projects found for the given manager");
        }
        else {
        	System.out.println("Projects handled by "+manName);
        	projectsByManager.forEach(e->System.out.println(e.getProjectName()+"/Budget:"+e.getBudget()));
        }
        
        System.out.println("Enter the status");
        String status = scanner.nextLine();
        if(status.equalsIgnoreCase("Completed")||status.equalsIgnoreCase("Pending")||status.equalsIgnoreCase("In progress")) {
        List<Project> projectsByStatus = pu.retrieveProjectsByStatus(projectList.stream(), status);
        
        if(projectsByStatus.isEmpty()) {
        	System.out.println("No projects found with the given status");
        }
        else {
        	System.out.println("Projects with status '"+status+"'");
        	projectsByStatus.forEach(e-> System.out.println("Project:"+e.getProjectName()+"/Manager:"+e.getManagerName()+"/Budget:"+e.getBudget()));                               
        }
        }
        else {
        	System.out.println("Invalid status");
        }
        System.out.println("Enter the budget limit");
        double limit = scanner.nextDouble();
        List<Project> projectsExceedingBudget = pu.retrieveProjectsExceedingBudget(projectList.stream(), limit);
        
        if(projectsExceedingBudget.isEmpty()) {
        	System.out.println("No projects found exceeding the given budget limit");
        }
        else {
        	System.out.println("Projects exceeding the budget limit");
        	projectsExceedingBudget.forEach(e-> System.out.println("Project:"+e.getProjectName()+"/Manager:"+e.getManagerName()+"/Budget:"+e.getBudget()));
        }
    }
}
