import java.time.LocalDate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.List;

public class CryptoTransactionUtil {
	CryptoTransaction ctransaction = new CryptoTransaction();
	public List<CryptoTransaction> getTransactionsAfterGivenDate(Stream<CryptoTransaction> transactionStream,LocalDate transactionDate) {
		//Fill the code here
		
		return transactionStream.filter(p->p.getTransactionDate().isAfter(transactionDate)).collect(Collectors.toList());
		
		
				
	}
	
	
	public CryptoTransaction getLatestTransaction(Stream<CryptoTransaction> transactionStream, String cryptoName) {
		//Fill the code here
		
//		transactionStream.sorted((p, q) -> p.getTransactionDate()  q.getTransactionDate()).map(e->e.getCryptoName());
		
		return null;
	}

	public List<String> getDistinctCryptocurrencies(Stream<CryptoTransaction> transactionStream) {
	    //Fill the code here
		
		return transactionStream.map(e->e.getCryptoName()).distinct().collect(Collectors.toList());
				
	}
}
