import java.util.Scanner;
import java.util.List;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

public class UserInterface {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        List<CryptoTransaction> transactions = new ArrayList<>();
        CryptoTransaction ct = new CryptoTransaction();
        
        DateTimeFormatter ldt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        System.out.println("Enter the number of transactions");
        int totalTransactions = sc.nextInt();
        sc.nextLine();
        
        System.out.println("Enter the transaction details");
        for (int i = 0; i < totalTransactions; i++) {
            String[] transactionDetails = sc.nextLine().split(":");
           
            String transactionId = transactionDetails[0];
            String cryptoName = transactionDetails[1];
            String date = transactionDetails[2];
            
            String transactionType = transactionDetails[3];
            double quantity = Double.parseDouble(transactionDetails[4]);
            double price = Double.parseDouble(transactionDetails[5]);
            LocalDate transactionDate = LocalDate.parse(date, ldt);
            
            ct.setTransactionId(transactionId);
            ct.setCryptoName(cryptoName);
            ct.setTransactionDate(transactionDate);
            ct.setTransactionType(transactionType);
            ct.setQuantity(quantity);
            ct.setPrice(price);
            transactions.add(ct);
        }
        
        
        
        //Fill the code here

    }
}
