import java.time.LocalDate;

public class CryptoTransaction {
    private String transactionId;
    private String cryptoName;
    private LocalDate transactionDate;
    private String transactionType;
    private double quantity;
    private double price;
    
    public CryptoTransaction(){
        
    }

    public CryptoTransaction(String transactionId, String cryptoName, LocalDate transactionDate,
                             String transactionType, double quantity, double price) {
        this.transactionId = transactionId;
        this.cryptoName = cryptoName;
        this.transactionDate = transactionDate;
        this.transactionType = transactionType;
        this.quantity = quantity;
        this.price = price;
    }

    public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getCryptoName() {
		return cryptoName;
	}


	public void setCryptoName(String cryptoName) {
		this.cryptoName = cryptoName;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
    public String toString() {
        return  transactionId +"|"+cryptoName +"|"+ transactionDate +"|"+ transactionType+"|"+quantity +"|"+ price;
    }
}
