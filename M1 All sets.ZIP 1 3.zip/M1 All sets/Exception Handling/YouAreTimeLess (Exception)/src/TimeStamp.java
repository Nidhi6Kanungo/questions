import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class TimeStamp {

	public boolean validateTimeStamp(LocalDateTime timeStamp) throws InvalidTimeStampException {

		if (timeStamp.isAfter(LocalDateTime.now())) {
            throw new InvalidTimeStampException("Timestamp is in the future");
        }
		
		DayOfWeek day = timeStamp.getDayOfWeek();
        if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
            throw new InvalidTimeStampException("Timestamp is on a weekend");
        }
        
        LocalTime time = timeStamp.toLocalTime();
        if (time.isBefore(LocalTime.of(9, 0)) || time.isAfter(LocalTime.of(17, 0))) {
            throw new InvalidTimeStampException("Timestamp is outside of business hours");
        }

        return true;
    }

	public String generateTimeStamp(LocalDateTime timeStamp) throws InvalidTimeStampException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        return timeStamp.format(formatter);
	}
}