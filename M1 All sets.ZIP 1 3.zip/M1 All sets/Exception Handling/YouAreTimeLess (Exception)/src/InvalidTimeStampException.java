public class InvalidTimeStampException extends Exception{
	
	public InvalidTimeStampException(String message) {
		super(message);
	}
}
