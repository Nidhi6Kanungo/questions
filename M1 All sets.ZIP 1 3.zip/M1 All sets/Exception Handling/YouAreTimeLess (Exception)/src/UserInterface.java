import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class UserInterface {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TimeStamp utility = new TimeStamp();

        System.out.println("Enter the timestamp");
        String input = sc.nextLine();
        
        try {
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime timeStamp = LocalDateTime.parse(input, inputFormatter);

            boolean isValid = utility.validateTimeStamp(timeStamp);
            if (isValid) {
                System.out.println("Timestamp is valid.");
                String formattedTimestamp = utility.generateTimeStamp(timeStamp);
                System.out.println("Formatted Timestamp: " + formattedTimestamp);
            }
        } catch (InvalidTimeStampException e) {
            System.out.println(e.getMessage());
        }
    }
}
