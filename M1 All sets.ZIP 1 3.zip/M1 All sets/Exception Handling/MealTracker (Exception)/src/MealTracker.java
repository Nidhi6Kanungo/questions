public class MealTracker {
	
	public String validateMealType(String mealType) throws InvalidMealException{
		
		if(mealType.equalsIgnoreCase("Snack")||mealType.equalsIgnoreCase("Dessert")||mealType.equalsIgnoreCase("Beverage")) {
			return "Validation successful";
		}
		else {
			throw new InvalidMealException("Invalid meal type. It should be either Snack, Dessert, or Beverage.");
		}
	          
    }
	
	public  String validateQuantity(int quantity) throws InvalidMealException{
	    
		if(quantity>0) {
			return "Validation Successful";
		}
		else
			throw new InvalidMealException("Invalid quantity. It should be greater than zero.");
			
	}

	 public int calculateTotalCalories(int quantity,int caloriesPerUnit) {

		 
	    return quantity*caloriesPerUnit;
	 }
}
