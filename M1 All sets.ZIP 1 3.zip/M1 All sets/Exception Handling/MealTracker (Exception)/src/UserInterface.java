import java.util.Scanner;

public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);        
        MealTracker ml = new MealTracker();
        
        while(true) {
        try {
        	System.out.println("Enter Meal Type (Snack Dessert or Beverage) :");
            String mealType = sc.nextLine();
			ml.validateMealType(mealType);
			break;
		} catch (InvalidMealException e) {
			System.out.println(e.getMessage());
			
		}
       }
        int qty=0;
        while(true) {
        	System.out.println("Enter Quantity:");
        	qty = sc.nextInt();
        
        	try {
				ml.validateQuantity(qty);
				break;
			} catch (InvalidMealException e) {
				// TODO: handle exception
				System.out.println(e.getMessage());
			}
        }
        
        System.out.println("Enter Calories per Unit:");
        int cal = sc.nextInt();
        int toCal = ml.calculateTotalCalories(qty, cal);
        System.out.println("Calories Consumed: "+toCal);
    }
}