public class InvalidMealException extends Exception {
    public InvalidMealException(String message) {
        super(message);
    }
}
