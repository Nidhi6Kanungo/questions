import java.util.regex.Pattern;

public class UserValidationService {
	
	public static User validateUser(String username, String password)throws InvalidUserException{
		User user = new User();
		if(username.length() < 6 || password.length() < 8) {
			throw new InvalidUserException("The username should contain minimum of 6 characters and password should contain minimum of 8 characters");
		}
		if(Pattern.matches("[\\d]{6}", username)  && Pattern.matches("[\\d]{8}", password)) {
		   throw new InvalidUserException("The username or password should not contain only numbers");
		}	
		
	    user.setUserName(username);
	    user.setPassword(password);
	    return user;
	}
}
