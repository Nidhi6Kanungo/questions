import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
		System.out.println("Enter the username");
		String username = sc.nextLine();
		
		System.out.println("Enter the password");
		String password = sc.nextLine();
		
		//UserValidationService userValidationService = new UserValidationService();
		
			User validateUser = UserValidationService.validateUser(username, password);
			try {
				boolean authenticateUser = validateUser.authenticateUser();
				if(authenticateUser) {
					System.out.println("UserAuthenticated");
				}
			} catch (UserNotFoundException a) {
				System.out.println(a.getMessage());
			}
		} catch (InvalidUserException e) {
			System.out.println(e.getMessage());
		}
	}
}
