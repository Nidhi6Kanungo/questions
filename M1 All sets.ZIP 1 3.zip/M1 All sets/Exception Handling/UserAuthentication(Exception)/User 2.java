public class User {
	private String userName;
	private String password;
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public  boolean authenticateUser() throws UserNotFoundException {
		
		if(userName.equals("Johnpeter") && password.equals("John@12345")) {
			return true;
		}
		else {
			if(!userName.equals("Johnpeter") && password.equals("John@12345")) {
				throw new UserNotFoundException("Username does not exists");
			}
			throw new UserNotFoundException("Username and password does not match");
		}
		
	}
}
