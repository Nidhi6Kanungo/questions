
public class GymMaster {
    
	public String validateWorkoutType(String workoutType) throws InvalidWorkoutException {
        
        //fill the code here
		
        if(workoutType.equals("Cardio")||workoutType.equals("Strength Training")||workoutType.equals("Flexibity")) {
        	return workoutType;
        }else {
        	throw new InvalidWorkoutException("Invalid workout type. It should be either Cardio, Strength Training, or Flexibility.");
        }
    
    }

    public int validateDuration(int duration) throws InvalidWorkoutException  {
        
        //fill the code here
        if(duration>0) {
        	return duration;
        }
        else {
        	throw new InvalidWorkoutException("Invalid duration. It should be a positive integer.");
        }
             
    }

	public int calculateCaloriesBurnt(String workoutType,int duration) {
	    int caloriesBurntPerMinute=0;
	   
	    //fill the code here
	        
	    if(workoutType.equals("Cardio")) {
	    	caloriesBurntPerMinute = duration*10;
	    }
	    else if(workoutType.equals("Strength Training")) {
	    	caloriesBurntPerMinute = duration*8;
	    }
	    else if(workoutType.equals("Flexibility")) {
	    	caloriesBurntPerMinute = duration*5;
	    }
	        
	    return caloriesBurntPerMinute;
	 }
	    
	    
}
