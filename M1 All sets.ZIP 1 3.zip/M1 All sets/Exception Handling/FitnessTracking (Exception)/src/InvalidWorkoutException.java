
public class InvalidWorkoutException extends Exception{
	
	public InvalidWorkoutException(String message) {
        super(message);
    }

}
