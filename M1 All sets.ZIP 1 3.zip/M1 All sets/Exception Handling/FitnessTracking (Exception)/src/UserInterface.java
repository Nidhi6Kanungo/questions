import java.util.Scanner;

public class UserInterface {
    
   public static void main(String[] args) {
    
    Scanner scanner = new Scanner(System.in);
    
        //fill the code here
    
    GymMaster gm = new GymMaster();
    Boolean b = true;
    String workoutType = null;
    while(b) {
	    System.out.println("Enter Workout Type:");
	    workoutType = scanner.nextLine();
	    try {
			gm.validateWorkoutType(workoutType);
			b=false;
		} catch (InvalidWorkoutException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    boolean b2 = true;
	    int duration = 0;
	    while(b2) {
		    System.out.println("Enter Duration:");
		    duration = scanner.nextInt();
		    scanner.nextLine();
		    try {
				gm.validateDuration(duration);
				b2 = false;
			} catch (InvalidWorkoutException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    System.out.println("Enter User Weight:");
	    int weight = scanner.nextInt();
	    scanner.nextLine();
	    System.out.println("Calories Burnt:"+gm.calculateCaloriesBurnt(workoutType, duration));
    }
    }
}