import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.*;
public class UserInterface {

    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter the number of words");
    	int n = sc.nextInt();
    	sc.nextLine();
    	
    	if(n < 2) {
    		System.out.println("Invalid word count");
    		return;
    	}
    	
    	System.out.println("Enter the words");
    	String[] arr = new String[n];
    	for(int i=0; i<n; i++) {
    		String item = sc.nextLine();
    		if(!Pattern.matches("[A-Za-z]{1,}", item)) {
    			System.out.println("Invalid input");
    			return;
    		}
    		else {
    			arr[i] = item;
    	    }
    	}
    		
    	String first = arr[0];
    	String find = "";
    	
    	for(int i=0; i<first.length()-1; i++) {
    		char c = Character.toLowerCase(first.charAt(i));
    		if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
    			switch (c) {
    			case 'a':
    				find += 'a';
    				break;
    			case 'e':
    				find += 'e';
    				break;
    			case 'i':
    				find += 'i';
    				break;
    			case 'o':
    				find += 'o';
    				break;
    			case 'u':
    				find += 'u';
    				break;
    			}
    		}
    	}
    	
    	Set<String> sets = new HashSet<>(Arrays.asList(find.split("")));
    	ArrayList<String> newSet = new ArrayList<>(sets); 

    	
    	ArrayList<String>  result = new ArrayList<>();
    	for(int i=1; i<arr.length; i++) {
			HashSet<String> hashset = new HashSet<>(Arrays.asList(arr[i].split("")));
			ArrayList<String> arrayList = new ArrayList<>(hashset); 
			int count = 0;
			
			for(String s: newSet) {

				if(arrayList.contains(s)) {
		    		count++;
		    	}
			}
			if(count == newSet.size()) {
				result.add(arr[i]);
			}
	    	
		}

    	
    	if(result.isEmpty()) {
    		System.out.println(arr[0]);
    	}
    	else {
    		System.out.println(arr[0]);
    		for(String arr1: result) {
        		System.out.println(arr1);
        	}
    	}
    	
    }
}


