import java.util.Scanner;

public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
    	String regex = "[a-z]{1,}";
        //System.out.println("Enter a string");
        String str = sc.nextLine();
        
        if(!str.matches(regex)) {
        	System.out.println("Invalid input");
        	return;
        }
        int chars = nonRepeatingChar(str);
        if(chars>=0)
        	System.out.println("The index of the first non repeating character is "+chars);
        else
        	System.out.println("There is no non repeating character");
        
        StringBuffer bf = findVowels(str);
       //System.out.println(bf.toString());
       
        String removeduplicate = removeduplicate(bf);
        //System.out.println(removeduplicate);
        //String n = new String();
        
        StringBuilder sb = new StringBuilder();
        for(int i=0;i<removeduplicate.length()-1;i++) {
        	sb.append(removeduplicate.charAt(i));
        	
        }
        if(sb.isEmpty())
        	System.out.println("No vowels present in the string");
        else
        System.out.println("Vowels in the string are "+sb.toString());
        
    }

	private static StringBuffer findVowels(String str) {
	
		char[]arr = str.toCharArray();
		String reg = "[aeiou]";
		StringBuffer bf = new StringBuffer();
		for (int i = 0; i < arr.length; i++) {
			
			if(arr[i]=='a'||arr[i]=='e'||arr[i]=='i'||arr[i]=='o'||arr[i]==+'u') {
				bf.append(arr[i]);
			}
		}
		
		return bf;
	}

	private static int nonRepeatingChar(String str) {
		// TODO Auto-generated method stub
		
		for(int i=0;i<str.length();i++) {
			int count=0;
			for(int j=0;j<str.length();j++) {
				if(str.charAt(i)==str.charAt(j))
					count++;
			}
			if(count==1)
				return i;
		}
		return -1;
		
	}
	
	static String removeduplicate(StringBuffer arr){
	
		StringBuffer sb = new StringBuffer();
		String str = "";
//		for (int i = 0; i < arr.length(); i++) {
//			//char ch = arr.charAt(i);
//			int count=0;
//			for(int j=i+1;j<arr.length();j++){
//				
//				if(arr.charAt(i)==arr.charAt(j))
//					count++;
//			}
//			if(count==0)
//				sb.append(arr.charAt(i)).append(" ");
//		}
		
		for (int i = 0; i < arr.length(); i++) {
			char ch = arr.charAt(i);
			if(str.indexOf(ch)==-1) {
				str +=ch+" ";
			}
			
		}
		return str;
	}
    
}
