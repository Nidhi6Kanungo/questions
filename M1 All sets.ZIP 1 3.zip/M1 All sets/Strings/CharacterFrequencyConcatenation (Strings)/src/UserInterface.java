import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String str = sc.nextLine();
        String reg = "[a-z]+";
        if(str.length()<2) {
        	System.out.println("Invalid Input");
        	return;
        }
        if(!Pattern.matches(reg, str)) {
        	System.out.println("Invalid word");
        	return;
        }else {
        	StringBuilder sb = new StringBuilder();
            char[] charArray = str.toCharArray();
            Arrays.sort(charArray);
            Map<Character ,Integer> hm = new LinkedHashMap<>();
            for(char cc : charArray) {
            	if(!hm.containsKey(cc)) {
            		hm.put(cc, 1);
            	}else {
            		hm.put(cc, hm.get(cc)+1);
            	}
            }
            
            for (Map.Entry<Character, Integer> entry : hm.entrySet()) {
				System.out.print(entry.getValue());
            }
        }
    }
}