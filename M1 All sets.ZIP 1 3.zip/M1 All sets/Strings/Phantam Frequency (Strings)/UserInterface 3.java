import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
    	//Fill the code here
        System.out.println("Enter the sentence");
        
        String sen = sc.next();
        sen+=sc.nextLine();

        int flag=0;
        for(int i=0;i<sen.length();i++) {
        	if(!((sen.charAt(i)>='a' && sen.charAt(i)<='z') || sen.charAt(i)==' ')) {
        		flag=1;
        		break;
        	}
        }
        if(flag==1) {
        	
        	System.out.println("Invalid input");
        }
        
        else {
        	
        	String[] arr = sen.split("\\s+");
        
        	int len = arr.length;
        	
        
        	if(!(len>=2)) {
        		System.out.println("Invalid Sentence");
        	}
        	else if((len>10)) {
        		System.out.println("Invalid Sentence");
        	}
        	else {
        		
        		StringBuffer sb = new StringBuffer();
        		
        		for(int i=0;i<sen.length();i++) {
        			
        			if(sen.charAt(i)!=' ') {
        				
        				sb.append(sen.charAt(i));
        				
        			}
        		}
        		
        		String s1 = sb.toString();
        		
        		StringBuffer sb1 = new StringBuffer();
        		
        		char[] arr1 = s1.toCharArray();
        		
        		char[] arr2 = s1.toCharArray();
        		
        		StringBuilder sb3 = new StringBuilder();
        		for(int i=0;i<arr1.length;i++) {
        			int count=0;
        			for(int j=0;j<arr2.length;j++) {
        				
        				if(arr1[i]==arr2[j]) {
        					count++;
        				}
        			}
        			sb3.append(arr1[i]+":"+count+" ");
        		}
        		String s4 = sb3.toString();
        		Map<String,Integer> map = new TreeMap<String, Integer>();
        		for(int i=0;i<arr1.length;i++) {
        			String[] split = s4.split("\\s+");
        			for(int j=0;j<split.length;j++) {
        				String[] split1 = split[i].split(":");
        				String str1 = split1[0];
        				int n2 = Integer.valueOf(split1[1]);
        				map.put(str1, n2);
        			}
        		}

        		List<String> list = new ArrayList<String>();
        		List<Integer> list1 = new ArrayList<Integer>();
        		Set<Entry<String, Integer>> map1 = map.entrySet();
        		for(Entry<String,Integer> ls : map1) {
        			
        			list.add(ls.getKey());
        			list1.add(ls.getValue());
        			
        		}

        		List<Integer> collect = list1.stream().sorted((n1,n2)->n1.intValue()>n2.intValue()?-1:1).collect(Collectors.toList());
        		for(int i=0;i<list.size();i++) {
        			if(collect.get(0)==list1.get(i)) {
        				
        				System.out.println(list.get(i)+" has high frequency and it occurs "+collect.get(0)+" times");
        			}
        		}
        	}
        }
    }
}
