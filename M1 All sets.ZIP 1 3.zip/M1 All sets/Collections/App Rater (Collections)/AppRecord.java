import java.util.List;
import java.util.Map;
import java.util.HashMap;

class AppRecord {
    private Map<String, Double> appMap = new HashMap<>();

    // Getter and Setter for appMap
    public Map<String, Double> getAppMap() {
        return appMap;
    }

    public void setAppMap(Map<String, Double> appMap) {
        this.appMap = appMap;
    }

    // Method to add app details
    public void addAppDetails(String appName, double rating) {
        // FILL THE CODE HERE
    	appMap.put(appName, rating);
    }

    // Method to count the number of apps with a rating above a specified value
    public int countAppsAboveRating(double rating) {
        // FILL THE CODE HERE
    	
    	long count = appMap.entrySet().stream().filter(p->p.getValue()>rating).count();
    	int count1=(int)count;
    	if(count1>0)
    	{
    		return count1;
    	}
	return 0;
    }

    // Method to find apps with rating above a specified value
    
    public List<String> findAppsWithHighRating() {
        // FILL THE CODE HERE
    	
    
		List<String> list = appMap.entrySet().stream().filter(p->p.getValue()>=3).map(p->p.getKey()).toList();
	return list;
    }
}