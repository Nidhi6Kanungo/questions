import java.util.List;
import java.util.Scanner;
public class UserInterface {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //Fill the code
        System.out.println("Enter the number of records to be added");
        int num=scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter the details(appName:rating)");
        AppRecord ap=null;
        for(int i=0;i<num;i++)
        {
        	String det=scanner.nextLine();
        	String arr[]=det.split(":");
        	if(arr.length==2)
        	{
        		String app=arr[0].trim();
        		double rating=Double.parseDouble(arr[1].trim());
        		ap=new AppRecord();
        		ap.addAppDetails(app, rating);
        		
        	}
        }
        
        System.out.println("Enter the rating value to count apps above it");
        double req=scanner.nextDouble();
        if(ap.countAppsAboveRating(req)<=0)
        {
        	System.out.println("No apps were found with a rating above "+req);
        }
        else {
        System.out.println("Number of apps with rating above "+req+" are "+ap.countAppsAboveRating(req));
        }
        
        List<String> appsWithHighRating = ap.findAppsWithHighRating();
        if(appsWithHighRating.isEmpty())
        {
        	System.out.println("No apps were found with a high rating");
        }
        else {
        	System.out.println("Apps with high rating are");
		        for(String a:appsWithHighRating)
		        {
		        	System.out.println(a);
		        }
        }
    }
}