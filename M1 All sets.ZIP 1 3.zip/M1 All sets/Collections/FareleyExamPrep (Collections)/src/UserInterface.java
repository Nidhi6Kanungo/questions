import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class UserInterface {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		AspirantInfo as = new AspirantInfo();
		System.out.println("Enter number of records to be added:");
		int num = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the details (Roll number : mark scored):");
		while (num > 0) {
			String str = sc.nextLine();
			String[] split = str.split(":");
			String name = split[0];
			double val = Double.parseDouble(split[1]);
			as.addAspirantDetails(name, val);
			num--;
		}
		System.out.println("Enter the roll number to be searched");
		String roll = sc.nextLine();
		double aspirantMark = as.findAspirantMark(roll);
		if (aspirantMark == -1) {
			System.out.println(roll + " is an invalid roll number");
		} else {
			System.out.println("Mark scored by the aspirant "+roll+" is " + aspirantMark);
		}

		List<String> mark = as.findAspirantsSelectedForTheSuperBatch();
		if(mark.size()==0) {
			System.out.println("None of the aspirants were selected for super batch");
			return;
		}
		System.out.println("Aspirants selected for the super batch are");
		for (String ss : mark) {
			System.out.println(ss);
		}
	}

}