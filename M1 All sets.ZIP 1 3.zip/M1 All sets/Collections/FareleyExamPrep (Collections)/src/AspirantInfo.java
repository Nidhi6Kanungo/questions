import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

public class AspirantInfo {
    
    private Map<String,Double> aspirantMap = new HashMap<String,Double>();
    
    public Map<String,Double> getAspirantMap() {
        return aspirantMap;
    }

    public void setAspirantMap(Map<String,Double> aspirantMap) {
        this.aspirantMap = aspirantMap;
    }
    
    public void addAspirantDetails(String rollNumber, double markScored) {
	
	// FILL THE CODE HERE
    	aspirantMap.put(rollNumber, markScored);
        
    }

    public double findAspirantMark(String rollNumber){
	
	// FILL THE CODE HERE
    	if(aspirantMap.containsKey(rollNumber)) {
    		Double double1 = aspirantMap.get(rollNumber);
    		return double1;
    	}
    	return -1;
       
    }

    public List<String> findAspirantsSelectedForTheSuperBatch() {
    	List<String> lst = new ArrayList<>();
    	for (Map.Entry<String, Double> entry : aspirantMap.entrySet()) {
			if(entry.getValue()>=80) {
				lst.add(entry.getKey());
			}
		}
	// FILL THE CODE HERE
    	return lst;
      
    }
}