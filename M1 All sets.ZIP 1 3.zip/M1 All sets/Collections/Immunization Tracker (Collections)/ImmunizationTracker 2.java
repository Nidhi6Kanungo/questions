import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.HashMap;

public class ImmunizationTracker {
    
    private Map<String, Integer> employeeImmunizationMap = new HashMap<>();

    public Map<String, Integer> getEmployeeImmunizationMap() {
        return employeeImmunizationMap;
    }

    public void setEmployeeImmunizationMap(Map<String, Integer> employeeImmunizationMap) {
        this.employeeImmunizationMap = employeeImmunizationMap;
    }

    public void addImmunizationDetails(String employeeId, int doseCount) {
        employeeImmunizationMap.put(employeeId, doseCount);
    }

    public int findDoseCountForGivenEmployeeId(String employeeId) {
    	int count = 0;
    	for(Map.Entry<String, Integer> entry: employeeImmunizationMap.entrySet()) {
    		if(entry.getKey().equalsIgnoreCase(employeeId)) {
    			count += entry.getValue();
    		}
    	}
    	
    	if(count == 0) {
    		return 0;
    	}
    	else {
    		return count;
    	}
	
    }

    public Map<String,Integer> findEmployeesBasedOnDoseCount(int doseCount) {
        Map<String, Integer> list = new HashMap<>();
        for(Map.Entry<String, Integer> entry: employeeImmunizationMap.entrySet()) {
        	if(entry.getValue() >= doseCount) {
        		list.put(entry.getKey(), entry.getValue());
        	}
        }
        
//        if(list.isEmpty()) {
//        	return null;
//        }
//        else {
        	return list;
        //}
        
    }
}
