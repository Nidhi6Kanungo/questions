import java.util.Map;
import java.util.Scanner;

public class UserInterface {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of records to be added");
        int n = sc.nextInt();
        sc.nextLine();
        
        System.out.println("Enter the details (employeeId : doseCount):");
        ImmunizationTracker immunizationTracker = new ImmunizationTracker();
        for(int i=0; i<n; i++) {
        	String s = sc.nextLine();
        	String[] str = s.split(":");
        	
        	immunizationTracker.addImmunizationDetails(str[0],Integer.parseInt(str[1]));
        }
        
        System.out.println("Enter the employeeId to get the doseCount");
        String empId = sc.nextLine();
        int findDoseCountForGivenEmployeeId = immunizationTracker.findDoseCountForGivenEmployeeId(empId);
        if(findDoseCountForGivenEmployeeId == 0) {
        	System.out.println("No employee was found for given employee id");
        }
        else {
        	
        	System.out.println("Dose Count: "+ findDoseCountForGivenEmployeeId);
        }
        
        
        System.out.println("Enter the doseCount to search for employee");
        int doseCount = sc.nextInt();
        Map<String, Integer> findEmployeesBasedOnDoseCount = immunizationTracker.findEmployeesBasedOnDoseCount(doseCount);
        if(findEmployeesBasedOnDoseCount.isEmpty()) {
        	System.out.println("No employees were found for given dose count");
        }
        else {
        	System.out.println("Employees with the given doseCount are");
        	for(Map.Entry<String, Integer> entry: findEmployeesBasedOnDoseCount.entrySet()) {
        		System.out.println(entry.getKey()+ ":" +entry.getValue());
        	}
        }
    }
}
