import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.HashMap;

public class ImmunizationTracker {
    
    private Map<String, Integer> employeeImmunizationMap = new HashMap<>();

    public Map<String, Integer> getEmployeeImmunizationMap() {
        return employeeImmunizationMap;
    }

    public void setEmployeeImmunizationMap(Map<String, Integer> employeeImmunizationMap) {
        this.employeeImmunizationMap = employeeImmunizationMap;
    }

    public void addImmunizationDetails(String employeeId, int doseCount) {
        //Fill the code here
    	employeeImmunizationMap.put(employeeId, doseCount);
    }

    public int findDoseCountForGivenEmployeeId(String employeeId) {
    	//Fill the code here
    	
    	//int count =0;
    	int num =0;
    	Set<Entry<String, Integer>> entrySet = employeeImmunizationMap.entrySet();
    	
    	for(Entry<String,Integer> ls : entrySet) {
    		if(ls.getKey().equalsIgnoreCase(employeeId)) {
    			//count++;
    			num= ls.getValue();
    			break;
    		}
    		
    	
    		//num= ls.getValue();
    		//break;
    	}
    	
	return num;
    }

    public Map<String,Integer> findEmployeesBasedOnDoseCount(int doseCount) {
        //Fill the code here
    	Map<String,Integer> map = new HashMap<String, Integer>();
    	Set<Entry<String, Integer>> entrySet = employeeImmunizationMap.entrySet();
    	
    	for(Entry<String,Integer> ls : entrySet) {
    		
    		if(ls.getValue()>=doseCount) {
    			
    			map.put(ls.getKey(),ls.getValue());
    		}
    	}
        return map;
    }
}
