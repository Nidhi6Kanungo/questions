import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class UserInterface {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        //Fill the code here
        
        ImmunizationTracker it = new ImmunizationTracker();
        System.out.println("Enter the number of records to be added");
        int len = sc.nextInt();
        
        
        System.out.println("Enter the details (employeeId : doseCount):");
        String[] arr = new String[len];
        for(int i=0;i<len;i++) {
        	
        	arr[i]=sc.next();
        	
        	String[] arr1 = arr[i].split(":");
        	
        	String s1 = arr1[0];
        	int n2 = Integer.valueOf(arr1[1]);
        	
        	it.addImmunizationDetails(s1, n2);
        	
        	
        }
        
        System.out.println("Enter the employeeId to get the doseCount");
        String str1 = sc.next();
        
        
        if(it.findDoseCountForGivenEmployeeId(str1)==0) {
        	System.out.println("No employee was found for given employee id");
        	
        }
        else {
        	System.out.println("Dose Count: "+it.findDoseCountForGivenEmployeeId(str1));
        }
        
        
        System.out.println("Enter the doseCount to search for employee");
        int count = sc.nextInt();
        
        
        if(it.findEmployeesBasedOnDoseCount(count).isEmpty()) {
        	System.out.println("No employees were found for given dose count");
        }
        else {
        	
        	System.out.println("Employees with the given doseCount are");
        	
        	Set<Entry<String, Integer>> entrySet = it.findEmployeesBasedOnDoseCount(count).entrySet();
        	
        	for(Entry<String,Integer> ls : entrySet) {
        		
        		System.out.println(ls.getKey()+":"+ls.getValue());
        	}
        }
        
        
    }
}
