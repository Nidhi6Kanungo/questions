import java.util.List;
import java.util.Scanner;

public class UserInterface {
	public static void main(String args[])
	{
		EnrollmentManager em = new EnrollmentManager();
	    Scanner sc=new Scanner(System.in);
	    System.out.println("Enter the number of enrollments to be added");
	    int count =sc.nextInt();
	    System.out.println("Enter the student records (StudentID:CourseName)");
	    sc.nextLine();
	    for(int i=0;i<count;i++) {
	    	String str = sc.nextLine();
	    	String[] arr = str.split(":");
	    	em.addEnrollmentDetails(arr[0], arr[1]);
	    }
	    
	    System.out.println("Enter the course name to find the total number of students enrolled");
	    String st1 = sc.nextLine();
	    
	    int totalStudentCountInCourse = em.findTotalStudentCountInCourse(st1);
	    if(totalStudentCountInCourse>=1) {
	    	System.out.println("Total students enrolled in "+st1+" is "+totalStudentCountInCourse);
	    }
	    else
	    	System.out.println("No students are found for "+st1);
	    
	    System.out.println("Enter the course names to find students enrolled");
	    String c1 = sc.nextLine();
	    String c2 = sc.nextLine();
	    
	    List<String> studentIdsEnrolledInCourses = em.findStudentIdsEnrolledInCourses(c1, c2);
	    if(studentIdsEnrolledInCourses.isEmpty())
	    	System.out.println("No students are found for either "+c1+" or "+c2);
	    else {
	    	System.out.println("Students enrolled in "+c1+" and "+c2+" are");
	    	studentIdsEnrolledInCourses.forEach(e -> System.out.println(e));
	    }
	}
	
}