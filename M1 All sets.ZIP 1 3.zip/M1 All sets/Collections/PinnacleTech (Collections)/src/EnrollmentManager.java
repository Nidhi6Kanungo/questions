
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EnrollmentManager {

	private Map<String, String> enrollmentMap= new HashMap<>();

	public EnrollmentManager() {

	}

	public Map<String, String> getEnrollmentMap() {
		return enrollmentMap;
	}

	public void setEnrollmentMap(Map<String, String> enrollmentMap) {
		this.enrollmentMap = enrollmentMap;
	}

	public void addEnrollmentDetails(String studentId, String courseName) {
		// FILL THE CODE HERE
		enrollmentMap.put(studentId, courseName);
	}

	public int findTotalStudentCountInCourse(String courseName) {
		// FILL THE CODE HERE
		if(enrollmentMap.isEmpty())
			return -1;
		int count=0;
		for(Map.Entry<String, String> entry : enrollmentMap.entrySet()) {
			if(entry.getValue().equalsIgnoreCase(courseName))
				count++;
		}
		if(count==0)
			return -1;
		return count;
	}

	public List<String> findStudentIdsEnrolledInCourses(String courseName1, String courseName2) {
		// FILL THE CODE HERE
		if(enrollmentMap.isEmpty()) {
			return null;
		}
		List<String> list = new ArrayList<String>();
		for(Map.Entry<String, String> entry:enrollmentMap.entrySet()) {
			if(entry.getValue().equalsIgnoreCase(courseName1))
				list.add(entry.getKey());
			if(entry.getValue().equalsIgnoreCase(courseName2))
				list.add(entry.getKey());
		}
//		if(list.isEmpty())
//			return null;
		return list;
	}
}
